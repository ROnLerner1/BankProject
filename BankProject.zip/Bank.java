import java.util.ArrayList;
import java.util.List;

public class Bank {
	private String bankName; 
	private ArrayList <BankAccount> accounts;
	
	
	public Bank(String bankName) {
		this.bankName = bankName;
		this.accounts = new ArrayList <>();
		
		
	}
	
    public void addAccount(BankAccount account) {
        accounts.add(account);
    }
    
    
	public String getBankName() {
		return bankName;
	}


	public ArrayList<BankAccount> getAccounts() {
		return accounts;
	}
	
	
	public void  openRegularAccount(String OwnerName) {
		RegularbanckAccount regularAccount = new RegularbanckAccount (OwnerName);
		accounts.add(regularAccount);
		
	}
	
	public void openCreditAccount (String OwnerName, double Credit, double interest) {
		CreditAccount CreditbankAccount = new CreditAccount (OwnerName, Credit, interest);
		accounts.add(CreditbankAccount);
		
		}

	
	public void deposit (int accountNumber, double amount) {
		for(BankAccount account: accounts) {
			if (account.getAccountNumber()== accountNumber) {
				account.deposit(amount);
				return;
				
			}
		}
		System.out.println("account not found!");
	
	}
	
	public void withdraw (int accountNumber, double amount) {
		
		for (BankAccount account: accounts) {
			if (account.getAccountNumber()== accountNumber) {
				account.withdraw(amount);
				return;

			}
		}
		System.out.println("account not found!");

	}

    

	 public double checkBalance (int accountNumber) {
	        for (BankAccount account : accounts) {
	            if (account.getAccountNumber() == accountNumber) {
	                return account.getBalance();
	            }
	        }
	        return -1; 

 
	    }
	    public BankAccount findAccount(int accountNumber) {
	        for (BankAccount account : accounts) {
	            if (account.getAccountNumber() == accountNumber) {
	                return account;
	            }
	        }
	        return null;
	    }
	    

	    public List<BankAccount> findAccountsByOwner(String ownerName) {
	        List<BankAccount> result = new ArrayList<>();
	        for (BankAccount account : accounts) {
	            if (account.getOwnerName().equalsIgnoreCase(ownerName)) {
	                result.add(account);
	            }
	        }
	        return result;
	    }

	    public List<BankAccount> getAllAccounts() {
	        return accounts;
	    }
	    
	    @Override
	    public String toString() {
	        String txt = "Bank Name: " + bankName ;
	        for (BankAccount b: accounts) {
	        	  txt += "\n" + b.getAccountNumber() + ":" + b;	            }
	        
	        return txt.toString();
	    }
	    

}	




