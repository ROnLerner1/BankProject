
public abstract class BankAccount {
	
	private static int nextAccountnumber = 1000; 
	protected int accountNumber;
	protected String ownerName; 
	protected double balance; 

	
	public BankAccount(String ownerName) {
		this.accountNumber=nextAccountnumber++;
		this.ownerName= ownerName;
		this.balance= 0;
		
	}

	public int getAccountNumber() {
		return accountNumber;
	}


	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}


	public String getOwnerName() {
		return ownerName;
	}


	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}


	public double getBalance() {
		return balance;
	}


	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	@Override
	public String toString () {
		return "Bank Account[account number: " + accountNumber + "Owner Name: " + ownerName + "balance: " + balance+ "]"; 
	}
	
	

	public abstract void deposit(double amount);
	public abstract boolean  withdraw(double amount);
    public abstract void addTransaction(String type, double amount);
	

}

	
	 
		
	
	 
	
	
	
	


