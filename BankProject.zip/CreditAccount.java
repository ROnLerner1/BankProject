
public class CreditAccount extends RegularbanckAccount {
	private double Credit;
	private double interest;
	
	
	public CreditAccount(String ownerName, double credit, double interest) {
		super(ownerName);
		this.Credit = credit;
		this.interest = interest;
	}


	public double getCredit() {
		return Credit;
	}


	public double getInterest() {
		return interest;
	
	}
	
	
	@Override
	public boolean withdraw(double amount) {
		if (balance + Credit >= amount) {
			balance-=amount;
            addTransaction("w", amount);
			return true;
		}else {
	        System.out.println("You can't withdraw money");
			return false;
		}

		}
	
	@Override
	public String toString() {
		return "Credit Account" + "[transaction: " + this.getTransaction() + ", ownerName: " + this.getOwnerName() + ", balance:" + this.getBalance() + ", Credit=" + Credit + ", interest=" + interest + "]";
	}
	
	
	
	
	
	
	
	
	
	

	

}

