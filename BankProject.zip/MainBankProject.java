import java.util.List;
import java.util.Scanner;

public class MainBankProject {
	
    private static Bank bank = new Bank("MyBank");
   
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);   
        bank.addAccount(new RegularbanckAccount("Alice"));
        bank.addAccount(new RegularbanckAccount("Bob"));
        bank.addAccount(new CreditAccount("Charlie", 1000, 5));
		System.out.println(bank.toString());
 
        int choice;   
        do {   	 
            printMainMenu();
            choice = scanner.nextInt();
            scanner.nextLine(); 

            if (choice == 1) {
                openAccount(scanner);
            } else if (choice == 2) {
                deposit(scanner);
            } else if (choice == 3) {
                withdraw(scanner);
            } else if (choice == 4) {
                transfer(scanner);
            } else if (choice == 5) {
                checkBalance(scanner);
            } else if (choice == 6) {
                viewTransactions(scanner);
            } else if (choice == 7) {
                generateReports(scanner);
            } else if (choice == 0) {
                System.out.println("You have exited the menu");
            } else {
                System.out.println("Invalid choice. Please try again.");
            }
            
  
        } while (choice != 0);

        scanner.close();
    }
 
    private static void printMainMenu() {
        System.out.println("Main Menu: ");
        System.out.println("1. Open new account");
        System.out.println("2. Deposit money");
        System.out.println("3. Withdraw money");
        System.out.println("4. Transfer money");
        System.out.println("5. Check balance");
        System.out.println("6. View transactions");
        System.out.println("7. Reports");
        System.out.println("0. Exit");
        System.out.print("Enter your choice: ");
    }

    
    private static void openAccount(Scanner scanner) {
        System.out.print("Enter owner name: ");
        String ownerName = scanner.nextLine();
        System.out.print("Enter account type (1 for Regular, 2 for Credit): ");
        int accountType = scanner.nextInt();

        if (accountType == 1) {
            bank.addAccount(new RegularbanckAccount(ownerName));
        } else if (accountType == 2) {
            System.out.print("Enter credit limit: ");
            double creditLimit = scanner.nextDouble();
            System.out.print("Enter interest rate: ");
            double interestRate = scanner.nextDouble();
            bank.addAccount(new CreditAccount(ownerName, creditLimit, interestRate));
        } else {
            System.out.println("Invalid account type");
        }

        System.out.println("Account opened successfully");
    }
    
    
    private static void deposit(Scanner scanner) {
        System.out.print("Please enter account number: ");
        int accountNumber = scanner.nextInt();
        System.out.print("Enter amount to deposit: ");
        double amount = scanner.nextDouble();

        BankAccount account = bank.findAccount(accountNumber);
        if (account != null) {
            account.deposit(amount);
            System.out.println("Deposit successful");
        } else {
            System.out.println("Account not found");
        }
    }

    private static void withdraw(Scanner scanner) {
        System.out.print("Enter account number: ");
        int accountNumber = scanner.nextInt();
        System.out.print("Enter amount to withdraw: ");
        double amount = scanner.nextDouble();

        BankAccount account = bank.findAccount(accountNumber);
        if (account != null) {
            if (account.withdraw(amount)) {
                System.out.println("Withdrawal successful.");
            }
        } else {
            System.out.println("Account not found.");
        }
    }

    private static void transfer(Scanner scanner) {
        System.out.print("Enter source account number: ");
        int sourceAccountNumber = scanner.nextInt();
        System.out.print("Enter target account number: ");
        int targetAccountNumber = scanner.nextInt();
        System.out.print("Enter amount to transfer: ");
        double amount = scanner.nextDouble();

        BankAccount sourceAccount = bank.findAccount(sourceAccountNumber);
        BankAccount targetAccount = bank.findAccount(targetAccountNumber);

        if (sourceAccount != null && targetAccount != null) {
            if (sourceAccount.withdraw(amount)) {
                targetAccount.deposit(amount);
                System.out.println("Transfer successful.");
            }
        } else {
            System.out.println("One or both accounts not found.");
        }
    }

    private static void checkBalance(Scanner scanner) {
        System.out.print("Enter account number: ");
        int accountNumber = scanner.nextInt();

        BankAccount account = bank.findAccount(accountNumber);
        if (account != null) {
            System.out.println("Balance: " + account.getBalance());
        } else {
            System.out.println("Account not found.");
        }
    }

    private static void viewTransactions(Scanner scanner) {
        System.out.print("Enter account number: ");
        int accountNumber = scanner.nextInt();

        BankAccount account = bank.findAccount(accountNumber);
        if (account != null) {
            if (account instanceof RegularbanckAccount) {
            	RegularbanckAccount regularAccount = (RegularbanckAccount) account;
                System.out.println("Recent transactions for Regular Bank Account:");
                for (Transactions transaction : regularAccount.getTransaction()) {
                    System.out.println(transaction);
                }
            } else if (account instanceof CreditAccount) {
                CreditAccount creditAccount = (CreditAccount) account;
                System.out.println("Recent transactions for Credit Account:");
                for (Transactions transaction : creditAccount.getTransaction()) {
                    System.out.println(transaction);
                }
            }
        } else {
            System.out.println("Account not found or not a regular/credit account.");
        }
    }


    
    private static void generateReports(Scanner scanner) {	 
        int reportChoice;     
        do {
            printReportMenu(); 
            reportChoice = scanner.nextInt();
            if (reportChoice == 1) {
                System.out.print("Enter owner name: ");
                String ownerName = scanner.nextLine();
                List<BankAccount> accountsByOwner = bank.findAccountsByOwner(ownerName);
                for (BankAccount account : accountsByOwner) {
                    System.out.println(account);
                }
            } else if (reportChoice == 2) {
                List<BankAccount> allAccounts = bank.getAllAccounts();
                for (BankAccount account : allAccounts) {
                    System.out.println(account);
                }

            } else if (reportChoice != 0) {
                System.out.println("Invalid choice. Please try again.");
            }
        } while (reportChoice != 0);
    }

     
    private static void printReportMenu() {
        System.out.println("Reports Menu: ");
        System.out.println(" 1. Find accounts by owner name");
        System.out.println(" 2. List all accounts");
        System.out.println(" 3. List all credit accounts");
        System.out.println(" 0. Back to main menu");
        System.out.print(" Enter your choice: ");
    }

}

