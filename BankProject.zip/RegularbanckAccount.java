import java.util.ArrayList;


public class RegularbanckAccount extends BankAccount {
	protected ArrayList <Transactions> transaction;
	
	
	public RegularbanckAccount(String ownerName) {
		super(ownerName);
		this.transaction = new ArrayList <> ();
	}
	
	
	
	public ArrayList<Transactions> getTransaction() {
		return transaction;
	}


	@Override
	
	public void deposit(double amount) {
		balance+=amount;
        addTransaction("d", amount);
	
	}

    @Override
    public boolean withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
            addTransaction("w", amount);
            return true;
        } else {
            System.out.println("cant withdraw");
            return false;
        }
    }

	
	
	   @Override
	    public void addTransaction(String type, double amount) {
	        transaction.add(new Transactions(type, amount));
	        if (transaction.size() > 5) {
	            transaction.remove(0);
	        }
	    }

	@Override
	public String toString() {
		return "Regular banck Account:[transaction: " + this.getTransaction() + ", ownerName: " + this.ownerName + ", balance:" + this.balance+ "]";
	}
	

}

