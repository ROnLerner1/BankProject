import java.time.LocalDateTime;

public class Transactions {
	private LocalDateTime time;  
	private String type;
	private double amount;
	
	
	public Transactions(String type, double amount) {
        this.time = LocalDateTime.now();
		this.type = type;
		this.amount = amount;
	}
	

	public LocalDateTime getTime() {
		return time;
	}


	public String getType() {
		return type;
	}


	public double getAmount() {
		return amount;
	}
	
	
	@Override
    public String toString() {
        return "Transaction{" +
                "date=" + time +
                ", type='" + type + '\'' +
                ", amount=" + amount +
                '}';
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		

}

